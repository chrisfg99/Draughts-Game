import pygame as pg 
from .counter import Counter
from .values import BLACK,P1,P2,SQ_SIZE,ROWS,COLS,BLUE,WHITE

#class to handle the pieces and drawing of board
class CheckerBoard:
    def __init__(self,):
        #create the board and its representation using a 2d list
        self.checkerboard=[]
        self.create_checkerboard()
        #how many of each players counters remain
        self.p2_remains=12
        self.p1_remains=12
        self.p2_king_remains=0
        self.p1_king_remains=0
        self.selected_counter=None
        self.Ldouble=False
        self.Rdouble=False


#/////DRAW AND CREATE FUNCTIONS
    #function to draw the checkerboard pattern
    def draw_sqrs(self,window):
        window.fill(BLACK)
        for row in range(ROWS):
            #equation in for loop to paint everyother square 1 colour
            for col in range(row % 2, ROWS, 2):
                #draw a rectangle to the given specification
                pg.draw.rect(window,WHITE,(row*SQ_SIZE, col*SQ_SIZE, SQ_SIZE, SQ_SIZE))

    #function to create the boards representation
    def create_checkerboard(self):
        for row in range(ROWS):
            self.checkerboard.append([])
            for col in range(COLS):
                #if statement and equation to add counter on every other square
                if col%2==((row+1)%2):
                    if row<3:
                        self.checkerboard[row].append(Counter(row,col,P1))
                    elif row>4:
                        self.checkerboard[row].append(Counter(row,col,P2))
                    else:
                #add blank space inbetween
                        self.checkerboard[row].append(0)
                else:
                    self.checkerboard[row].append(0)
    
    #using the representation from create_checkerboard, draw the checkerboard in GUI
    def draw_checkerboard(self,window,hints):
        #create the squares
        self.draw_sqrs(window)
        #check each square and see what is in its position
        for row in range(ROWS):
            for col in range(COLS):
                counter=self.checkerboard[row][col]
                if counter !=0:
                    #if there is a counter in a square draw it on the board
                    counter.draw_counter(window)
                    if hints==True and self.selected_counter!=None:
                        valids=self.get_valids()
                        for i in valids:
                            if len(i)!=0:
                                self.rowV,self.colV=i[0]
                                pg.draw.circle(window,BLUE,(SQ_SIZE*self.colV+SQ_SIZE//2,SQ_SIZE*self.rowV+SQ_SIZE//2),10)

#//////COUNTER RELATED FUNCTIONS
    #function to get counter from given coordinates
    def get_counter(self, row, col):
        return self.checkerboard[row][col]

    #function to move given counter to coordinates in the representation
    def move_checkerboard(self, counter, row, col):
        #check if counter is about to reach the top or bottom of the board
        self.check_for_corination(counter,row)
        #swaps the 2 values of where the counter is and where it wants to go
        temp=self.checkerboard[counter.row][counter.col]
        self.checkerboard[counter.row][counter.col]= self.checkerboard[row][col]
        self.checkerboard[row][col]=temp
        #passes this value to the counter
        counter.move_counter(row,col)

    #function to remove a counter from the board
    def remove_counter(self,counter):
        #set given coordinates to 0 and lower the count of the given players counters and if king lower the king value too
        if counter.colour==P1:
            self.p1_remains-=1
            if counter.king==True:
                self.p1_king_remains-=1
        if counter.colour==P2:
            self.p2_remains-=1
            if counter.king==True:
                self.p2_king_remains-=1
        self.checkerboard[counter.row][counter.col]=0

#//////CHECK FUNCTIONS
    #function to check if counter should be made crowned
    def check_for_corination(self,counter,row):
        #if counter is going to be at the top or bottom make it a king and increase king count for that player
        if row==0 or row==ROWS-1:
            if counter.colour==P1:
                self.p1_king_remains+=1
            else:
                self.p2_king_remains+=1
            counter.crown()
    
    #function to see if someone has won e.g. opponents counters =0
    #called by run when a piece is removed
    def check_for_winner(self):
        if self.p1_remains<=0 and self.p2_remains<=0:
            return "It's a Tie, nobody"
        if self.p1_remains<=0:
            return 'The Human'
        if self.p2_remains<=0:
            return 'The AI'

#/////Functions for validation
    #function that gets all valid moves
    def get_valids(self):
        moves=[]
        counter=self.selected_counter
        self.mustJump=False
        #check left and right diagonals in the heading of the counter
        moves.append(self.check_diag(counter,-1,counter.heading))
        moves.append(self.check_diag(counter,1,counter.heading))
        #if the right has a counter moves needs to be cleared to make the counter jump right 
        if self.mustJump==True:
            moves=[]
            moves.append(self.check_diag(counter,1,counter.heading))
            moves.append(self.check_diag(counter,-1,counter.heading))
        #if another move can be taken double is set to true for left or right diagonal
        while self.Ldouble==True:
            col=counter.col+(-4)
            row=counter.row+(counter.heading*4)
            moves.append([[row,col]])
            self.check_double(-1,counter.heading,row,col,counter)
        while self.Rdouble==True:
            col=counter.col+4
            row=counter.row+(counter.heading*4)
            moves.append([[row,col]])
            self.check_double(1,counter.heading,row,col,counter)
        #check left and right in opposite headings as well if king
        temp=moves.copy()
        if counter.king==True:
            #create variables
            self.oldJumps=False
            first=0
            if self.mustJump==True:
                self.oldJumps=True 
            self.mustJump=False    
            moves.append(self.check_diag(counter,-1,-counter.heading))
            if self.mustJump==True:
                first=1
            moves.append(self.check_diag(counter,1,-counter.heading))
            if self.oldJumps==True and self.mustJump==False:
                moves=temp
            elif self.oldJumps==False and self.mustJump==True:
                moves=[]
                if first==0:
                    moves.append(self.check_diag(counter,1,-counter.heading))
                    moves.append(self.check_diag(counter,-1,-counter.heading))
                else:
                    moves.append(self.check_diag(counter,-1,-counter.heading))
                    moves.append(self.check_diag(counter,1,-counter.heading))
            elif self.oldJumps==True and self.mustJump==True:
                moves=temp
                if first==0:
                    moves.append(self.check_diag(counter,1,-counter.heading))
                    moves.append(self.check_diag(counter,-1,-counter.heading))
                else:
                    moves.append(self.check_diag(counter,-1,-counter.heading))
                    moves.append(self.check_diag(counter,1,-counter.heading))
            #if another move can be taken double is set to true for left or right diagonal
            while self.Ldouble==True:
                col=counter.col+(-4)
                row=counter.row+(counter.heading*4)
                moves.append([[row,col]])
                self.check_double(-1,-counter.heading,row,col,counter)
            while self.Rdouble==True:
                col=counter.col+4
                row=counter.row+(counter.heading*4)
                moves.append([[row,col]])
                self.check_double(1,-counter.heading,row,col,counter)
        return moves
    
    #check a diagonal path for valid moves with left being -1 and right being +1
    def check_diag(self,counter,LR,heading):
        moves=[]
        #move column left or right and row up or down depending on values
        col=counter.col+LR
        row=counter.row+heading
        #if new position is not out of bounds
        if row<=ROWS-1 and row>=0 and col<=COLS-1 and col>=0: 
            #if there is a counter there and it is not of our colour
            if self.checkerboard[row][col]!=0 and self.get_counter(row,col).colour!=counter.colour:
                #calc row and col of next square in diag
                col=col+LR
                row=row+heading
                #if there is an empty space after the above counter return it as a valid move and check for double jump
                if col>=0 and col<=COLS-1 and row>=0 and row<=ROWS-1:
                    if self.get_counter(row,col)==0:
                        self.mustJump=True
                        moves.append([row,col])
                        #check if a double jump is possible
                        self.check_double(LR,heading,row,col,counter)
                        return moves
            #if there is no counter
            elif self.checkerboard[row][col]==0 and self.mustJump==False:
                moves.append([row,col])
        #if out of bounds return empty moves
        return moves

    #function to check if a double jump is possible 
    def check_double(self,LR,heading,row,col,counter):
        #calc new square again
        col,row=(col+LR),(row+heading)
        #if new square is not out of bounds
        if row<=ROWS-1 and row>=0 and col<=COLS-1 and col>=0: 
            #if there is a counter there and it is not of our colour
            if self.checkerboard[row][col]!=0 and self.get_counter(row,col).colour!=counter.colour:
                #calc row and col of next sqaure in diag
                col=col+LR
                row=row+heading
                if row<=ROWS-1 and row>=0 and col<=COLS-1 and col>=0: 
                    #if there is an empty space after the above counter
                    if self.get_counter(row,col)==0:
                        #set right double to true if the right has a space else the left
                        if LR==1:
                            self.Rdouble=True
                            return
                        else:
                            self.Ldouble=True
                            return
        #if there is no move set the approprtiate double to False
        if LR==1:
            self.Rdouble=False
        else:
            self.Ldouble=False

    #check jump function(new_row,new_col)
    def check_jump(self,new_row,new_col,regicide):
        print("checkerboard has selected:",self.selected_counter)
        old_row, old_col=self.selected_counter.row,self.selected_counter.col
        #calc if counter is going left or right
        LR=-1
        if old_col<new_col:
            LR=1
        #calc which heading the counter is going in
        heading=-1
        if old_row<new_row:
            heading=1    
        #while the old position doesn't equal the new position
        while (old_row,old_col)!=(new_row,new_col) and old_row<=ROWS-1 and old_row>=0 and old_col<=COLS-1 and old_col>=0:
            square=self.get_counter(old_row,old_col)
            #if there is a counter in the square and it is of a different colour
            if square!=0 and square.colour!=self.selected_counter.colour:
                #remove the counter thats present
                self.remove_counter(square)
                #if the removed counter is a king and regicide = true then make selected a king
                if square.king==True and regicide==True:
                    self.selected_counter.crown()
            old_row+=heading
            old_col+=LR

    #function that looks for if there are any more valid moves to be made 
    def check_moves(self,player):        
        #check to see if there are valid moves counters can do
        if self.any_moves(player)==False:
            #if there are none the player with the highest number of pieces wins
            if self.p2_remains>self.p1_remains:
                self.p1_remains=0
            elif self.p2_remains<self.p1_remains:
                self.p2_remains=0
            else:
                #if there are the same number of counters its a tie
                self.p2_remains=0
                self.p1_remains=0

#//////Functions used by the AI
    #check for if there are any valid moves left
    def any_moves(self,player):
        row,col=0,0
        # go through each row adn column looking for a counter
        for row in range (ROWS):
            for col in range (COLS):
                if self.checkerboard[row][col]!=0 and self.checkerboard[row][col].colour==player:
                    #once found check if that counter has any valid moves
                    self.selected_counter=self.get_counter(row,col)
                    self.valids=self.get_valids()
                    self.selected_counter=None
                    validMoves = 0
                    for move in self.valids:
                        if len(move)!=0:
                            validMoves +=1
                    if validMoves!=0:
                        return True
        #if there are no valid moves return false
        return False
    
    #function to evaluate the board
    def evaluate(self,player):
        if player==P1:
            return self.p2_remains-self.p1_remains+self.p2_king_remains-self.p1_king_remains
        if player==P2:
            return self.p1_remains-self.p2_remains+self.p1_king_remains-self.p2_king_remains

    #function that can undo the last move
    def undoMove(self,counter):
        self.checkerboard[counter.row][counter.col]=0
        self.checkerboard[counter.last_position[0]][counter.last_position[0]]=counter
        counter.row,counter.col=counter.last_position
