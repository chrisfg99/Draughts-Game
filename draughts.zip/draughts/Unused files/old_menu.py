from tkinter import *
import pygame as pg
from .run import Run
from draughts.constants import WHITE
from draughts.constants import WIDTH 
from draughts.constants import HEIGHT
from draughts.constants import SQ_SIZE
from draughts.checkerboard import CheckerBoard

class Menu(Frame):
    def __init__(self,window):
        Frame.__init__(self,window)
        self.window=window
        self.create_components()

######Components of the menu
    def create_components(self):
        Title=Label(self.window,text="Draughts Game",font="calibri,20",pady="20")
        Title.grid(row=1,column=2)

        Subtitle=Label(self.window,text="Main Menu",font="calibri,10",pady="20")
        Subtitle.grid(row=2,column=2)

        Play=Button(self.window,width=20, fg="red", text="Start Game", command=lambda:self.runGame())
        Play.grid(row=4,column=2)

        Rules=Button(self.window,width=20, fg="red", text="Rules")
        Rules.grid(row=5,column=2)

        Options=Button(self.window,width=20, fg="red", text="Options", command=lambda:self.rules())
        Options.grid(row=6,column=2)

######Menu functions
    #get the position of the cursor     
    def cursor_pos(self,pos):    
        col=pos[0]//SQ_SIZE
        row=pos[1]//SQ_SIZE
        return row,col

    #function to operate the run class and check for events occuring
    def runGame(self):
        self.window.destroy()
        #set window names and size
        WINDOW = pg.display.set_mode((WIDTH, HEIGHT))
        
        pg.display.set_caption('Draughts')
        #call run class
        run=Run(WINDOW)
        #create a clock that runs the game at 60hz
        clk=pg.time.Clock()
        running=True
        while running==True:
            clk.tick(60)
            #checks the game for any event that occurs
            for event in pg.event.get():
                #if person clicks run the event for selection by giving position of the cursor
                if event.type==pg.MOUSEBUTTONDOWN:
                    positon=pg.mouse.get_pos()
                    row,col=self.cursor_pos(positon)
                    run.select_square(row,col)
                    #print(row,col)
                    #print(run.checkerboard.checkerboard)
                #if person quits end the run loop and quit the game
                if event.type==pg.QUIT:
                    running=False
                    main()
            #if statement to check if anyone has won yet
            if run.checkerboard.check_for_winner()!=None:
                running=False
                #REPLACE WITH POP UP WINDOW################################################
                print(run.checkerboard.check_for_winner(),' is the winner')
            #draw the checkerboard and update the display
            run.update_window()

    #function to operate options class
    def options(self):
        print('options')

    #function to operate the rules pop up
    def rules(self):
        print('rules')

def main():
    root=Tk()
    root.title("Draughts Main Menu")
    root.iconbitmap(r'circle_favicon.ico')
    app=Menu(root)
    root.mainloop()

main()
