import pygame as pg
from tkinter import *
from tkinter.messagebox import showinfo
from .checkerboard import CheckerBoard
from .values import P2
from .values import P1
from .values import COLS
from .values import ROWS
from .values import hints
from .values import regicide
from .values import difficulty

#class that takes care of all components when the program is running
class Run():
    def __init__(self,window,difficulty,regicide,hints):
        self.difficulty=difficulty
        self.reset_game(window,difficulty,regicide,hints)
        Tk().withdraw()

#/////Functions for general display    
    #function that resets all values back to their originals
    def reset_game(self,window,difficulty,regicide,hints):
        self.selected_counter=None
        self.valids={}
        self.checkerboard=CheckerBoard()
        self.go = P2
        self.Ldouble=False
        self.Rdouble=False
        self.regicide=regicide
        self.hints=hints
        self.window=window

    #function to update the window display
    def update_window(self):
        if hints==True:
            
        else:
            self.checkerboard.draw_checkerboard(self.window,[])
        pg.display.update()

#/////Functions for rule based functions e.g. changing turns
    #function to change whose turn it is
    def switch_go(self):
        if self.go==P1:
            self.go=P2
        elif self.go==P2:
            self.go=P1
        else:
            showinfo("Error",'Turn error')

#/////Functions for selecting squares and counters
    #function for selecting a square from the grid
    def select_square(self,row,col):
        #check if a counter has already been selected
        if self.selected_counter!=None:
            #if new square has a counter try selecting that counter instead
            if self.checkerboard.checkerboard[row][col]!=0:
                self.select_counter(row,col)
            #if it doesn't then try moving the counter to newly selected square
            else: 
                valid=self.move_counter(row,col)
                #if true is returned the counter has been moved so reset selection
                if valid==True:
                    self.selected_counter=None
        #if it hasn't try selecting that counter
        else:
            self.select_counter(row,col)

    #function for selecting a counter
    def select_counter(self,row,col):
        #if selected square has a counter select the counter
        if self.checkerboard.checkerboard[row][col]!=0:
            #if its this players turn select the counter and get valid moves
            if self.go==(self.checkerboard.get_counter(row,col)).colour:
                self.selected_counter=self.checkerboard.get_counter(row,col)
                self.valids=self.get_valids()
                if self.hints==True:
                    counter=self.selected_counter
                    while self.selected_counter==counter:
                        self.checkerboard.display_valids(self.window,self.valids)
            else:
                self.selected_counter=None
                showinfo("Message",'Sorry not your go')
        else:
            self.selected_counter=None
            showinfo("Message",'Select square with your counter')
            
#///////Function for moving counters       
    def move_counter(self,row,col):
        #if the square is empty and the move is valid move selected counter to the given row and column
        if self.selected_counter!=0 and [[row,col]] in self.valids:
            self.check_jump(row,col)
            self.checkerboard.move_checkerboard(self.selected_counter,row,col)
            self.check_moves()
            self.switch_go()
        elif self.mustJump==True:
            #if must jump is true
            showinfo("Error",'This piece must capture a counter')
        else:
            #if the above is not true return false
            showinfo("Error","Invalid Move\nThis piece either can't move in this direction\nOr it must capture a counter")
            return False
        #if counter is moved successfully return true
        return True
    
#/////Functions for validation
    #function that gets all valid moves
    def get_valids(self):
        moves=[]
        counter=self.selected_counter
        self.mustJump=False
        #check left and right diagonals in the heading of the counter
        moves.append(self.check_diag(counter,-1,counter.heading))
        moves.append(self.check_diag(counter,1,counter.heading))
        #if the right has a counter moves needs to be cleared to make the counter jump right 
        if self.mustJump==True:
            moves=[]
            moves.append(self.check_diag(counter,1,counter.heading))
            moves.append(self.check_diag(counter,-1,counter.heading))
        #if another move can be taken double is set to true for left or right diagonal
        while self.Ldouble==True:
            col=counter.col+(-4)
            row=counter.row+(counter.heading*4)
            moves.append([[row,col]])
            self.check_double(-1,counter.heading,row,col,counter)
        while self.Rdouble==True:
            col=counter.col+4
            row=counter.row+(counter.heading*4)
            moves.append([[row,col]])
            self.check_double(1,counter.heading,row,col,counter)

        #check left and right in opposite headings as well if king
        if counter.king==True:
            if self.mustJump==False:
                moves=[]         
            self.mustJump=False
            temp=moves
            moves.append(self.check_diag(counter,-1,-counter.heading))
            moves.append(self.check_diag(counter,1,-counter.heading))
            if self.mustJump==True:
                moves=temp
                moves.append(self.check_diag(counter,1,-counter.heading))
                moves.append(self.check_diag(counter,-1,-counter.heading))
            #if another move can be taken double is set to true for left or right diagonal
            while self.Ldouble==True:
                col=counter.col+(-4)
                row=counter.row+(counter.heading*4)
                moves.append([[row,col]])
                self.check_double(-1,-counter.heading,row,col,counter)
            while self.Rdouble==True:
                col=counter.col+4
                row=counter.row+(counter.heading*4)
                moves.append([[row,col]])
                self.check_double(1,-counter.heading,row,col,counter)
        return moves
    
    #check a diagonal path for valid moves with left being -1 and right being +1
    def check_diag(self,counter,LR,heading):
        moves=[]
        #move column left or right and row up or down depending on values
        col=counter.col+LR
        row=counter.row+heading
        #if new position is not out of bounds
        if row<=ROWS-1 and row>=0 and col<=COLS-1 and col>=0: 
            #if there is a counter there and it is not of our colour
            if self.checkerboard.checkerboard[row][col]!=0 and self.checkerboard.get_counter(row,col).colour!=counter.colour:
                #calc row and col of next square in diag
                col=col+LR
                row=row+heading
                #if there is an empty space after the above counter return it as a valid move and check for double jump
                if col>=0 and col<=COLS-1 and row>=0 and row<=ROWS-1:
                    if self.checkerboard.get_counter(row,col)==0:
                        self.mustJump=True
                        moves.append([row,col])
                        #check if a double jump is possible
                        self.check_double(LR,heading,row,col,counter)
                        return moves
            #if there is no counter
            elif self.checkerboard.checkerboard[row][col]==0 and self.mustJump==False:
                moves.append([row,col])
        #if out of bounds return empty moves
        return moves

    #function to check if a double jump is possible 
    def check_double(self,LR,heading,row,col,counter):
        #calc new square again
        col,row=(col+LR),(row+heading)
        #if new square is not out of bounds
        if row<=ROWS-1 and row>=0 and col<=COLS-1 and col>=0: 
            #if there is a counter there and it is not of our colour
            if self.checkerboard.checkerboard[row][col]!=0 and self.checkerboard.get_counter(row,col).colour!=counter.colour:
                #calc row and col of next sqaure in diag
                col=col+LR
                row=row+heading
                if row<=ROWS-1 and row>=0 and col<=COLS-1 and col>=0: 
                    #if there is an empty space after the above counter
                    if self.checkerboard.get_counter(row,col)==0:
                        #set right double to true if the right has a space else the left
                        if LR==1:
                            self.Rdouble=True
                            return
                        else:
                            self.Ldouble=True
                            return
        #if there is no move set the approprtiate double to False
        if LR==1:
            self.Rdouble=False
        else:
            self.Ldouble=False

    #check jump function(new_row,new_col)
    def check_jump(self,new_row,new_col):
        old_row, old_col=self.selected_counter.row, self.selected_counter.col
        #calc if counter is going left or right
        LR=-1
        if old_col<new_col:
            LR=1
        #calc which heading the counter is going in
        heading=-1
        if old_row<new_row:
            heading=1    
        #while the old position doesn't equal the new position
        while (old_row,old_col)!=(new_row,new_col) and old_row<=ROWS-1 and old_row>=0 and old_col<=COLS-1 and old_col>=0:
            square=self.checkerboard.get_counter(old_row,old_col)
            #if there is a counter in the square and it is of a different colour
            if square!=0 and square.colour!=self.selected_counter.colour:
                #remove the counter thats present
                self.checkerboard.remove_counter(square)
                #if the removed counter is a king and regicide = true then make selected a king
                if square.king==True and self.regicide==True:
                    self.selected_counter.crown()
            old_row+=heading
            old_col+=LR

    #function that looks for if there are any more valid moves to be made 
    def check_moves(self):        
        #check to see if there are valid moves counters can do
        if self.any_moves()==False:
            #if there are none the player with the highest number of pieces wins
            if self.checkerboard.p2_remains>self.checkerboard.p1_remains:
                self.checkerboard.p1_remains=0
            elif self.checkerboard.p2_remains<self.checkerboard.p1_remains:
                self.checkerboard.p2_remains=0
            else:
                #if there are the same number of counters its a tie
                self.checkerboard.p2_remains=0
                self.checkerboard.p1_remains=0

    #check for if there are any valid moves left
    def any_moves(self):
        row,col=0,0
        # go through each row adn column looking for a counter
        for row in range (ROWS-1):
            for col in range (COLS-1):
                if self.checkerboard.checkerboard[row][col]!=0 and self.checkerboard.checkerboard[row][col].colour==self.selected_counter.colour:
                    #once found check if that counter has any valid moves
                    self.selected_counter=self.checkerboard.get_counter(row,col)
                    self.valids=self.get_valids()
                    self.selected_counter=0
                    validMoves = 0
                    for move in self.valids:
                        if len(move)!=0:
                            validMoves +=1
                    if validMoves==0:
                        return True
                    else:
                        #if there is at least one valid move return true
                        return True
        #if there are no valid moves return false
        return False