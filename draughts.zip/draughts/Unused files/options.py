import tkinter
from tkinter import *
from tkinter.messagebox import showinfo
from draughts import menu

class Options():
    def __init__(self,window):
        self.window=window
        self.create_components()
       
        
######Components of options
    def create_components(self):
        self.difficultyVar=StringVar(self.window, value="Easy")
        self.regicideVar=BooleanVar()
        self.hintsVar=BooleanVar()

        Title=Label(self.window,text="Options",font="calibri 30",pady="20", bg="white")
        Title.grid(row=1,column=2)

        optionsTitle=Label(self.window,text="Difficulty",font="calibri 15", bg="white")
        optionsTitle.grid(row=3,column=2)

        difficulty=OptionMenu(self.window, self.difficultyVar, "Easy", "Medium", "Hard")
        difficulty.grid(row=4,column=2)

        coloursTitle=Label(self.window,text="Colour Settings",font="calibri 15", bg="white")
        coloursTitle.grid(row=5,column=2)

        gameTitle=Label(self.window,text="Game settings",font="calibri 15", bg="white")
        gameTitle.grid(row=7,column=2)

        regicideBox=Checkbutton(self.window, variable=self.regicideVar, text="Regicide", bg="white")
        regicideBox.grid(row=8,column=2)

        hintBox=Checkbutton(self.window, variable=self.hintsVar, text="Hints", bg="white")
        hintBox.grid(row=9,column=2)
        
        save=Button(self.window,width=20, text="Save & Exit", bg="white", command=lambda:self.exit())
        save.grid(row=10,column=2)


########Functions of options   
    def save(self):
        difficulty=self.difficultyVar.get()
        regicide=self.regicideVar.get()
        hints=self.hintsVar.get()
        self.window.destroy()
        print(difficulty)
        return difficulty, regicide, hints

    def exit(self):
        menu.exited=True




#bit for the main menu
def make_options(self):
        root=Tk()
        root.title("Options Menu")
        root.iconbitmap(r'circle_favicon.ico')
        root.columnconfigure(1,minsize=200)
        root.columnconfigure(3,minsize=200)
        root.rowconfigure(10,minsize=300)
        root.configure(bg="white")
        root.resizable(False,False)
        Options(root)
        root.mainloop()
