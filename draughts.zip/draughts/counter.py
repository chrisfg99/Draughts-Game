import pygame as pg
from .values import P1
from .values import P2
from .values import WHITE,BLACK,SQ_SIZE,PADDING,BORDER,KING,BLUE

#class representing all counters found in the game
class Counter:
    def __init__(self,row,col,colour):
        #all variables that are initiated in the creation of the counter class
        self.colour=colour
        #depending on colour depends which way the counter will head towards
        if self.colour==P2:
            self.heading=-1
        if self.colour==P1:
            self.heading=1
        #variables controlling the positioning of the chip
        self.col=col
        self.row=row
        self.x=0
        self.y=0
        self.calc_pos()
        #variable to decide if the counter is a king
        self.king=False
        self.last_position=row,col

#////Function that makes the counter a king once called
    def crown(self):
        self.king=True

#////Function to draw the counter onto the board
    def draw_counter(self,window):
        #equation for the radius of the counter
        r=SQ_SIZE//2-PADDING
        #if chosen counter is black add a white border
        if self.colour==BLACK:
            pg.draw.circle(window,WHITE,(self.x,self.y),r+BORDER)
            pg.draw.circle(window,self.colour,(self.x,self.y),r)
        #if not black then make the border the same colour
        else:
            pg.draw.circle(window,self.colour,(self.x,self.y),r+BORDER)
        #if the counter is a king add a crown
        if self.king==True:
            window.blit(KING,(self.x-KING.get_width()//2, self.y-KING.get_height()//2))
        
    
#/////Functions to control the positioning of the chip
    #simple function to update the counters coordinates
    def move_counter(self,row,col):
        self.last_position=self.row,self.col
        self.col=col
        self.row=row
        self.calc_pos()

    #function to work out where the middle of the square is in order to centre the counter
    def calc_pos(self):
        self.y=SQ_SIZE*self.row+SQ_SIZE//2
        self.x=SQ_SIZE*self.col+SQ_SIZE//2
    
