from .values import P1,P2,ROWS,COLS
from .checkerboard import CheckerBoard
from copy import deepcopy

#class containing all functions necessary to output the current best move for the AI
class AI():
    #initiates similar variables to that found in run
    def __init__(self,checkerboardCopy,regicide):
        self.checkerboard=checkerboardCopy
        self.regicide=regicide

    #function that will return the best possible move
    def get_bestMove(self,difficulty):
        #get all valid moves
        self.validMoves=self.get_moves(P1)
        if len(self.validMoves)!=0:
            #initialse all needed variables
            self.evaluations=0
            self.bestScore=100
            self.worstScore=0
            self.bestMove=self.validMoves[0][1]
            self.checkerboardCopy=deepcopy(self.checkerboard)
            #best score is returned by minimax function
            if difficulty=="Easy":
                move=self.miniMax(1,P1,3,0,0)
            elif difficulty=="Medium":
                move=self.miniMax(3,P1,5,0,0)
            elif difficulty=="Hard":
                move=self.miniMax(8,P1,10,0,0)
            #best score is found in sucessor and the counter and its move is returned 
            return move

    #function utilising the minimax algorithm
    def miniMax(self,depth,maxPlayer,eval_limit,a,B):
        #if it reaches the root
        if depth==0:
            #add 1 to the number of complete evaluations(branches)
            self.evaluations+=1
            #return the current score
            return self.checkerboard.evaluate(P1), self.bestMove
        if maxPlayer:
            self.bestScore=float("-inf")
            for move in self.get_moves(P1):
                #execute move
                tempP = deepcopy(move[0])
                self.checkerboard.selected_counter=move[0]
                row,col=move[1][0]
                self.checkerboard.check_jump(row,col,self.regicide)

                self.checkerboard.move_checkerboard(tempP,row,col)
                #get the score for this and all concurrent moves
                score=self.miniMax(depth-1,False,eval_limit,a,B)[0]
                #reset the board
                self.checkerboard=deepcopy(self.checkerboardCopy)
                #get highest of the two values
                self.bestScore=max(float(score),float(self.bestScore))
                if score==self.bestScore:
                    self.bestMove=move
                a=max(self.bestScore,a)
                #if beta <= alpha then prune
                if B<=a:
                    break
            return self.bestScore,self.bestMove
        else:
            self.bestScore=float("inf")
            for move in self.get_moves(P2):
                #execute move
                tempP = deepcopy(move[0])
                self.checkerboard.selected_counter=move[0]
                row,col=move[1][0]
                self.checkerboard.check_jump(row,col,self.regicide)

                self.checkerboard.move_checkerboard(tempP,row,col)
                #get the score for this and all concurrent moves
                score=self.miniMax(depth-1,False,eval_limit,a,B)[0]
                #reset the board
                self.checkerboard=deepcopy(self.checkerboardCopy)
                #get lowest of the two values
                worstScore=min(float(score),float(self.bestScore))
                if score==self.worstScore:
                    self.bestMove=move
                B=min(worstScore,B)
                #if beta <= alpha then prune
                if B<=a:
                    break
            return self.bestScore,self.bestMove

    #function to get all available moves
    def get_moves(self,player):
        validMoves=[]
        row,col=0,0
        # go through each row and column looking for a counter
        for row in range (ROWS):
            for col in range (COLS):
                #once found check if that counter is of players colours and if it has any valid moves
                if self.checkerboard.checkerboard[row][col]!=0 and self.checkerboard.checkerboard[row][col].colour==player:
                    self.checkerboard.selected_counter=self.checkerboard.checkerboard[row][col]
                    self.valids=self.checkerboard.get_valids()
                    #for each of the counters add its possible moves to the validMoves list
                    for move in self.valids:
                        validMove=[]
                        if len(move)!=0:
                            validMove=[self.checkerboard.selected_counter,move]
                            validMoves.append(validMove)
        return validMoves

    #a copy of the function from run
    def move_counter(self,row,col):
            #if the square is empty and the move is valid move selected counter to the given row and column
            if self.checkerboard.selected_counter!=None and [[row,col]] in self.valids:
                self.checkerboard.check_jump(row,col,self.regicide)
                self.checkerboard.move_checkerboard(self.checkerboard.selected_counter,row,col)
                self.checkerboard.check_moves()