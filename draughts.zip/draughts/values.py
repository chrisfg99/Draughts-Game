#File for all variables values
#Allows easy access to any values that could be changed
import pygame as pg
from tkinter import *

#set width & height of the display, default = 800px
WIDTH=800
HEIGHT=800

#set number of rows & columns, default board = 8 and 8
ROWS=8
COLS=8

#equation to calculate the size of the squares
SQ_SIZE=WIDTH//COLS

#colour RGB codes, don't change
WHITE=(255,255,255)
BLACK=(0,0,0)
GREY=(128,128,128)
BLUE=(0,0,255)
RED=(255,0,0)

#players choosen colours
P1=WHITE
P2=BLACK

#game values
difficulty="Easy"
regicide=1
hints=0

#get the PNG used for the king counter
king_PNG = pg.image.load('draughts\king.png')

#resize the king counter image
KING=pg.transform.scale(king_PNG,(50,50))

#how much space betwewen the edge of a sqare and the counter
PADDING=10
BORDER=2

