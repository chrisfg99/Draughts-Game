from tkinter.messagebox import showinfo
import pygame as pg
from tkinter import *
from draughts.run import Run
from draughts.values import WHITE,WIDTH,HEIGHT,SQ_SIZE,P1
import time
from draughts.checkerboard import CheckerBoard

class Menu():
    def __init__(self,window):
        self.window=window
        self.create_components()        

######Components of the menu
    def create_components(self):
        #variables
        self.difficultyVar=StringVar(self.window, value="Easy")
        self.regicideVar=BooleanVar()
        self.hintsVar=BooleanVar()
        self.pvpVar=BooleanVar()

        #left pane
        Title=Label(self.window,text="Draughts Game",font="calibri 42",pady="20",bg="white")
        Title.grid(row=1,column=2,columnspan=2)

        Subtitle=Label(self.window,text="Main Menu",font="calibri 15",pady="20", bg="white")
        Subtitle.grid(row=2,column=2,columnspan=2)

        Play=Button(self.window,width=20, text="Start Game", command=lambda:self.runGame(),bg="white")
        Play.grid(row=4,column=2)

        Rules=Button(self.window,width=20, text="Rules",bg="white", command=lambda:self.rules())
        Rules.grid(row=5,column=2)

        Subtitle=Label(self.window,text="Candidate Number:184521",font="calibri 10",pady="20",bg="white")
        Subtitle.grid(row=10,column=2,columnspan=2)

        #right pane
        optionsTitle=Label(self.window,text="Difficulty:",font="calibri 12", bg="white")
        optionsTitle.grid(row=4,column=3,sticky=W)

        difficulty=OptionMenu(self.window, self.difficultyVar, "Easy", "Medium", "Hard")
        difficulty.grid(row=4,column=3,sticky=E)

        regicideBox=Checkbutton(self.window, variable=self.regicideVar, text="Regicide", bg="white",onvalue=1,offvalue=0)
        regicideBox.grid(row=5,column=3,sticky=W)

        hintBox=Checkbutton(self.window, variable=self.hintsVar, text="Hints", bg="white",onvalue=1,offvalue=0)
        hintBox.grid(row=5,column=3,sticky=E)

        aiBox=Checkbutton(self.window, variable=self.pvpVar, text="PvP", bg="white",onvalue=1,offvalue=0)
        aiBox.grid(row=6,column=3)

######Menu functions
    #get the position of the cursor     
    def cursor_pos(self,pos):    
        col=pos[0]//SQ_SIZE
        row=pos[1]//SQ_SIZE
        return row,col

    #function to operate the run class and check for events occuring
    def runGame(self):  
        difficulty,regicide,hints,pvp=self.updateValues()
        #set window names and size
        WINDOW = pg.display.set_mode((WIDTH, HEIGHT))
        icon=pg.image.load('circle_favicon.png')
        pg.display.set_icon(icon)
        pg.display.set_caption('Draughts')
        #call run class
        run=Run(WINDOW,difficulty,regicide,hints)
        #create a clock that runs the game at 60hz
        clk=pg.time.Clock()
        running=True
        while running==True:
            run.checkerboard.draw_checkerboard(WINDOW,hints)
            pg.display.update()
            time.sleep(0.15)
            clk.tick(60)
            if run.go==P1 and pvp==False:
                run.move_AI()
            #checks the game for any event that occurs
            for event in pg.event.get():
                #if person clicks run the event for selection by giving position of the cursor 
                if event.type==pg.MOUSEBUTTONDOWN:
                    positon=pg.mouse.get_pos()
                    row,col=self.cursor_pos(positon)
                    run.select_square(row,col)
                #if person quits end the run loop and quit the game
                if event.type==pg.QUIT:
                    running=False
                    pg.display.quit()
                    self.window.deiconify()
            #if statement to check if anyone has won yet
            if run.checkerboard.check_for_winner()!=None:
                running=False
                showinfo("Game Over",run.checkerboard.check_for_winner()+' is the winner')
                pg.display.quit()
                self.main()           
            #draw the checkerboard and update the display
            run.update_window()
            #hide menu
            self.window.withdraw()

    #function to operate the rules pop up
    def rules(self):
        showinfo("RULES", 'Draught Game Rules\n\n' 
        "Starting\nThe Player will start at the bottom of the board and the AI will start at the top\n"
        'Left click on the center of a counter to select it and then left click on a square to move it there (selection sometimes requires a doubleclick after a pop up)\n\n'
        'Movement\nRegular pieces can only move 1 space diagonally towards the opposite end of the board\n'
        'King pieces can move 1 space diagonally in all directions\n\n'
        'Kings\nTo get a king piece, a piece must reach the opposite side of the board or capture a king piece (if regicide is enabled)\n'
        'Kings themselves are denoted by the crown symbol located on top of the piece\n\n'
        'Capturing\nTo capture a piece an opponents piece must be jumped therefore capturing that piece and removing it from the board\nDouble jumps require you to click on the last space in the move, are seen easily with hints enabled, and look like counter space counter space along a diagonal from your counter\n\n'
        'Winning\nTo win all the opponents pieces must be removed from the board or the opponent should have no more moves remaining\nThe AI will also be able to give up once its sees no way of winning\n'
        'Options\nThe options include; difficulty of the AI, showing the player valid moves, regicide(ablity to capture kings) and player vs player\n\n'
        'Troubleshooting\nIf the board becomes unresponsive, Alt+Tab and check for a pop up window that has not been closed and press ok untill all the pop ups have been closed')
   
######Functions to make windows
    #Function to recreate the window for the main menu
    def main(self):
        root=Tk()
        root.title("Draughts Main Menu")
        root.iconbitmap(r'circle_favicon.ico')
        root.columnconfigure(1,minsize=100)
        root.columnconfigure(4,minsize=100)
        root.rowconfigure(10,minsize=100)
        root.configure(bg="white")
        root.resizable(False,False)
        Menu(root)
        root.mainloop()

#####function to update game values
    def updateValues(self):
        self.difficulty=self.difficultyVar.get()
        self.regicide=self.regicideVar.get()
        self.hints=self.hintsVar.get()
        self.pvp=self.pvpVar.get()
        return self.difficulty,self.regicide,self.hints,self.pvp