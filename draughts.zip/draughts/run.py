import pygame as pg
from tkinter import *
from tkinter.messagebox import showinfo
from .checkerboard import CheckerBoard
from .values import P2,P1,COLS,ROWS,difficulty
from .AI import AI
from copy import deepcopy

#class that takes care of all components when the program is running
class Run():
    def __init__(self,window,difficulty,regicide,hints):
        self.difficulty=difficulty
        self.reset_game(window,difficulty,regicide,hints)
        Tk().withdraw()

#/////Functions for general display    
    #function that resets all values back to their originals
    def reset_game(self,window,difficulty,regicide,hints):
        self.selected_counter=None
        self.valids={}
        self.checkerboard=CheckerBoard()
        self.go = P2
        self.regicide=regicide
        self.hints=hints
        self.window=window

    #function to update the window display
    def update_window(self):
        self.checkerboard.draw_checkerboard(self.window,self.hints)
        pg.display.update()

#/////Functions for rule based functions e.g. changing turns
    #function to change whose turn it is
    def switch_go(self):
        if self.go==P1:
            self.go=P2
        elif self.go==P2:
            #once it its the AI's go get the best move the AI can make
            self.go=P1

#/////Functions for selecting squares and counters
    #function for selecting a square from the grid
    def select_square(self,row,col):
        #check if a counter has already been selected
        if self.selected_counter!=None:
            #if new square has a counter try selecting that counter instead
            if self.checkerboard.checkerboard[row][col]!=0:
                self.select_counter(row,col)
            #if it doesn't then try moving the counter to newly selected square
            else: 
                valid=self.move_counter(row,col)
                #if true is returned the counter has been moved so reset selection
                if valid==True:
                    self.selected_counter=None
        #if it hasn't try selecting that counter
        else:
            self.select_counter(row,col)

    #function for selecting a counter
    def select_counter(self,row,col):
        #if selected square has a counter select the counter
        if self.checkerboard.checkerboard[row][col]!=0:
            #if its this players turn select the counter and get valid moves
            if self.go==(self.checkerboard.get_counter(row,col)).colour:
                self.selected_counter=self.checkerboard.get_counter(row,col)
                self.checkerboard.selected_counter=self.selected_counter
                self.valids=self.checkerboard.get_valids()
            else:
                self.selected_counter=None
                showinfo("Message",'Sorry not your go')
        else:
            self.selected_counter=None
            showinfo("Message",'Select square with your counter')
            
#///////Function for moving counters       
    def move_counter(self,row,col):
        #if the square is empty and the move is valid move selected counter to the given row and column
        if self.selected_counter!=0 and [[row,col]] in self.valids:
            self.checkerboard.check_jump(row,col,self.regicide)
            self.checkerboard.move_checkerboard(self.selected_counter,row,col)
            if self.go==P1:
                self.checkerboard.check_moves(P2)
            elif self.go==P2:
                self.checkerboard.check_moves(P1)
            self.switch_go()
        elif self.checkerboard.mustJump==True:
            #if must jump is true
            showinfo("Error",'This piece must capture a counter')
        else:
            #if the above is not true return false
            showinfo("Error","Invalid Move\nThis piece either can't move in this direction\nOr it must capture a counter")
            return False
        #if counter is moved successfully return true
        return True
    
#///////Function for executing the AI
    def move_AI(self):
        #create an ai class cangive it the current board and regicide parameter
        self.AI=AI(deepcopy(self.checkerboard),self.regicide)
        #get best current move from the AI class 
        bestMove=self.AI.get_bestMove(self.difficulty)
        if (bestMove)!=None or len(bestMove)!=0:
            #execute the best move on the actial board and check if there are any moves left
            row,col=bestMove[1][1][0]
            counter=bestMove[1][0]
            self.select_counter(counter.row,counter.col)
            self.select_square(row,col)
            self.checkerboard.check_moves(P2)
        else:
            self.checkerboard.check_moves(P2)
        
